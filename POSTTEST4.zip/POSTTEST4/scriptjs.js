const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.register-link')

registerLink.addEventListener('click', ()=>{
    wrapper.classList.add('active');
});

loginLinkLink.addEventListener('click', ()=>{
    wrapper.classList.add('active');
});
